#include "apc.h"

int mul_num ( Dlist **tail1, Dlist **tail2, Dlist **head_res, Dlist **tail_res )
{
    int pro = 0, count = 1;
    Dlist *temp1 = *tail1, *temp2 = *tail2, *res = *tail_res;
    while( temp2 != NULL)
    {
	temp1 = *tail1, count = 1, pro = 0;
	while(temp1 != NULL)
	{
	    pro += temp1 -> data * temp2 -> data * count;
	    count *= 10;
	    temp1 = temp1 -> prev;
	}
	insert_at_first(head_res, tail_res, pro);
	temp2 = temp2 -> prev;
    }
    pro = 0,count = 1, res = *tail_res;
    while ( res != NULL )
    {
	res -> data *= count;
	pro += res->data;
	count *= 10;
	res = res -> prev;
    }
    (*tail_res)->data = pro;
    *head_res = *tail_res;
    return SUCCESS;
}

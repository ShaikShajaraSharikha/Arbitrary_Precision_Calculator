/* Documentation
Name:        Shaik Shajara Sharikha
Date:        21/12/2019
Description: Arbitrary-precision arithmetic, also called bignum arithmetic, multiple precision
             arithmetic, or sometimes infinite-precision arithmetic, indicates that calculations are performed on
             numbers whose digits of precision are limited only by the available memory of the host system. This
             contrasts with the faster fixed-precision arithmetic found in most Arithmetic Logic Unit hardware.
*/

#include "apc.h"

int main( int argc, char **argv )
{
    Dlist *head1 = NULL, *tail1 = NULL, *head2 = NULL, *tail2 = NULL, *head_res = NULL, *tail_res = NULL;
    if ( argc == 4 )
    {
	int length1 = strlen(argv[1]), length2 = strlen(argv[3]), num = 1, count = 0, data = 0, i;
	char str1[length1], str2[length2], ch;
	strcpy(str1, argv[1]);
	strcpy(str2, argv[3]);
	for (i = (length1 - 1); i >= 0; i--)
	{
	    ch = str1[i];
	    if (isdigit(ch) != 0)
	    {
		if (count < 3)
		{
		    data = data + ((ch - 48) * num);
		    num = num * 10;
		    count++;
		}
		else
		{
		    insert_at_first(&head1, &tail1, data);
		    count = 0;
		    data = 0;
		    num = 1;
		    i++;
		}
	    }
	    else
	    {
		printf("ERROR : Enter valid numbers and operator\nINFO : Enter the input as suggested\n\t./a.out 1234567892345 + 45678929870280\n");
		return 1;
	    }
	}
	insert_at_first(&head1, &tail1, data);
	num = 1, data = 0, count = 0;
	for (i = (length2 - 1); i >= 0; i--)
	{
	    ch = str2[i];
	    if (isdigit(ch) != 0)
	    {
		if (count < 3)
		{
		    data = data + ((ch - 48) * num);
		    num = num * 10;
		    count++;
		}
		else
		{
		    insert_at_first(&head2, &tail2, data);
		    count = 0;
		    data = 0;
		    num = 1;
		    i++;
		}
	    }
	    else
	    {
		printf("ERROR : Enter valid numbers and operator\nINFO : Enter the input as suggested\n\t./a.out 1234567892345 + 45678929870280\n");
		return 1;
	    }
	}
	insert_at_first(&head2, &tail2, data);
	if ( strcmp(argv[2], "+") == 0 )
	{
	    if ( add_num ( &head1, &tail1, &head2, &tail2, &head_res, &tail_res, length1, length2 ) == SUCCESS ) printf("INFO : Addition Result is ");
	}
	else if ( strcmp(argv[2], "-") == 0 )
	{
	    if ( sub_num ( &head1, &tail1, &head2, &tail2, &head_res, &tail_res, length1, length2 ) == SUCCESS ) printf("INFO : Subtraction Result is ");
	}
	else if ( strcmp(argv[2], "x") == 0 )
	{
	    tail1 = NULL, head1 = NULL, tail2 = NULL, head2 = NULL;
	    for (i = (length1 - 1); i >= 0; i--)
	    {
		ch = str1[i];
		if (isdigit(ch) != 0)
		{
		    data = ch - 48;
		    insert_at_first(&head1, &tail1, data);
		}
		else
		{
		    printf("ERROR : Enter valid numbers and operator\nINFO : Enter the input as suggested\n\t./a.out 1234567892345 x 45678929870280\n");
		    return 1;
		}
	    }
	    num = 1, data = 0, count = 0;
	    for (i = (length2 - 1); i >= 0; i--)
	    {
		ch = str2[i];
		if (isdigit(ch) != 0)
		{
		    data = ch - 48;
		    insert_at_first(&head2, &tail2, data);
		}
		else
		{
		    printf("ERROR : Enter valid numbers and operator\nINFO : Enter the input as suggested\n\t./a.out 1234567892345 x 45678929870280\n");
		    return 1;
		}
	    }
	    if ( mul_num ( &tail1, &tail2, &head_res, &tail_res ) == SUCCESS ) printf("INFO : Multiplication Result is ");
	}
	else
	{
        printf("ERROR : Enter valid numbers and operator\n");
    }
    return 0;
}

#ifndef DLIST_H
#define DLIST_H

#include <stdio.h>
#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SUCCESS 0
#define FAILURE 1
#define DATA_NOT_FOUND 2
#define FILE_NOT_PRESENT 3
#define DUPLICATE_FILE 4

//Structure for double linked list
typedef struct node
{
    int data;
    struct node *prev;
    struct node *next;
} Dlist;

//Function Prototypes
int add_num ( Dlist **, Dlist **, Dlist **, Dlist **, Dlist **, Dlist **, int, int );
int sub_num ( Dlist **, Dlist **, Dlist **, Dlist **, Dlist **, Dlist **, int, int );
int insert_at_first(Dlist **head, Dlist **tail, int data);
int mul_num ( Dlist **, Dlist **, Dlist **, Dlist ** );
int div_num ( Dlist **, Dlist **, Dlist **, Dlist ** );
void print_list ( Dlist * );

#endif

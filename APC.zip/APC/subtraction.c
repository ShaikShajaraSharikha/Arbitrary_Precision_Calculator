#include"apc.h"

int sub_num ( Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **head_res, Dlist **tail_res, int length1, int length2 )
{
    Dlist *temp, *temp1 = *tail1, *temp2 = *tail2;
    int difference, borrow = 0;
    while (length1 < length2)
    {
	length1++;
	insert_at_first(head1, tail1, 0);
    }
    while (length2 < length1)
    {
	length2++;
	insert_at_first(head2, tail2, 0);
    }
    if ( (*head1)->data < (*head2)->data )
    {
	temp = temp1;
	temp1 = temp2;
	temp2 = temp;
	borrow = 1;
    }
    else
	borrow = 0;
    while ( temp1 && temp2 )
    {
	while ( temp1->data < temp2->data && temp1 != *head1 )
	{
	    temp1->data += 1000;
	    if ( temp1->prev != NULL )
	    temp1->prev->data -= 1;
	}
	difference = temp1->data - temp2->data;
	printf("temp1->data %d\t\t", temp1->data);
	printf("temp2->data %d\t\t", temp2->data);
	printf("difference %d\n", difference);
	insert_at_first(head_res,tail_res, difference);
	temp1 = temp1->prev;
	temp2 = temp2->prev;
    }
	if ( borrow == 1 )
	    (*head_res)->data = -difference;
    return SUCCESS;
}

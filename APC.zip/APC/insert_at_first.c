#include "apc.h"

int insert_at_first(Dlist **head, Dlist **tail, int data)
{
    Dlist *temp = *head;
    //1.Create a node
    Dlist *new = malloc(sizeof(Dlist));
    //2.Check whether node is created or not
    if ( new == NULL )
    {
	return FAILURE;
    }
    //3.Check whether the list is empty
    if ( *head == NULL )
    {
	//3.1 Update data and links
	new -> data = data;
	new -> prev = NULL;
	*head = new;
	*tail = new;
	new -> next = NULL;
	return SUCCESS;
    }
    //4.Update the data and links
    new -> data = data;
    new -> prev = NULL;
    new -> next = NULL;
    //5.Check whether the list is non_empty 
    if ( *head != NULL )
    {
	//5.1 Update data and links
	new -> next = temp;
	temp -> prev = new;
	*head = new;
    }
    return SUCCESS;
}

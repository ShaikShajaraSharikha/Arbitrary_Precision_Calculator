#include"apc.h"

int add_num ( Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **head_res, Dlist **tail_res, int length1, int length2 )
{
    Dlist *temp1 = *tail1, *temp2 = *tail2;
    int sum = 0, carry = 0;
    while (length1 < length2)
    {
	insert_at_first(head1, tail1, 0);
	length1++;
    }
    while (length2 < length1)
    {
	insert_at_first(head2, tail2, 0);
	length2++;
    }
    while ( temp1 && temp2 )
    {
	sum = temp1->data + temp2->data + carry;
	printf("temp1->data %d\t\t", temp1->data);
	printf("temp2->data %d\t\t", temp2->data);
	if (sum > 999)
	{
	    carry = 1;
	    if (temp1->data != (*head1)->data)
	    {
		sum = sum - 1000;
	    }
	}
	else
	{
	    carry = 0;
	}
	printf("sum %d\n", sum);
	insert_at_first(head_res,tail_res, sum);
	temp1 = temp1->prev;
	temp2 = temp2->prev;
    }
    return SUCCESS;
}

#include "apc.h"

void print_list(Dlist *head)
{
    //Take local reference to traverse through the link
    Dlist *temp = head;
    //Check whether the list is empty
    if(temp == NULL )
    {
	printf("List is EMPTY\n");
    }
    //Traverse till last node
    while (temp != NULL)
    {
	printf("%d", temp->data);
	temp = temp -> next;
    }
    printf("\n");
}

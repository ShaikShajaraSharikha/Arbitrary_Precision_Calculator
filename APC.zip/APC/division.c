#include "apc.h"

int div_num ( Dlist **tail1, Dlist **tail2, Dlist **head_res, Dlist **tail_res )
{
	int div = 0, count = 1, carry = 0;
	Dlist *temp1 = *tail1,*temp2 = *tail2, *res = *tail_res;
	while( temp2 != NULL)
	{
		temp1 = *tail1, count = 1, div = 0;
		while(temp1 != NULL)
		{
			div += (temp1 -> data * count) / temp2 -> data;
			count *= 1000;
			temp1 = temp1 -> prev;
		}
		printf("%d\n", div);
		insert_at_first(head_res,tail_res,div);
		temp2 = temp2 -> prev;
	}
	div = 0,count = 1, res = *tail_res;
      while ( res != NULL )
      {
          res -> data *= count;
  //      printf("%d\n", res->data);
          div += res->data;
          count *= 10;
          res = res -> prev;
      }
	(*tail_res)->data = div;
	*head_res = *tail_res;
	return SUCCESS;
}
